package com.apalya.myplex.adapters;

public interface ScrollingDirection {
	public void scrollDirection(boolean value); 
}
