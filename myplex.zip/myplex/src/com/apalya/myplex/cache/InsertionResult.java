package com.apalya.myplex.cache;


public interface InsertionResult {
	public void updateComplete(Boolean updateStatus);

}


