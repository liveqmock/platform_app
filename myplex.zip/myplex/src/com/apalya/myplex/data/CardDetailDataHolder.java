package com.apalya.myplex.data;

public class CardDetailDataHolder {
	public boolean mShowinQuickLaunch;
	public String mFilterName;
	public String mLabel;
	public CardDetailBaseData mData;
	public int mViewPosition;
//	public CardDetailDataHolder(int type,String label,String sectionname){
//		this.type = type;
//		this.label = label;
//		this.sectionName = sectionname;
//	}
	

}
