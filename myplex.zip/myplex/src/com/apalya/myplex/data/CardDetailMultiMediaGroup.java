package com.apalya.myplex.data;

import java.util.ArrayList;

public class CardDetailMultiMediaGroup {
	public ArrayList<CardDetailMediaData> mList = new ArrayList<CardDetailMediaData>();
	public String groupName;
	public String groupDescription;
	public int groupType;
}
