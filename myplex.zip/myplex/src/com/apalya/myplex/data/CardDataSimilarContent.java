package com.apalya.myplex.data;

import java.util.List;

public class CardDataSimilarContent {
	public List<CardData> values;
	public CardDataSimilarContent(){}
}
