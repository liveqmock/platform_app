package com.apalya.myplex.data;

public class CardDetailCommentData {
	public String mMessage;
	public String mName;
	public String mDate;
}
