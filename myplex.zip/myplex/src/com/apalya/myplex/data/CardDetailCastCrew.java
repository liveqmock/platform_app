package com.apalya.myplex.data;

public class CardDetailCastCrew {
	public String leftText;
	public String rightText;
}
