package com.apalya.myplex.data;

public class CardDetailMediaData {
	public String mThumbnailName;
	public String mThumbnailDescription;
	public String mThumbnailUrl;
	public String mThumbnailMime;
}
