package com.apalya.myplex.data;

public class slidemenudata {
	public String title;
	public String imageUrl;
	public int resID;
	public slidemenudata(String title,String imageUrl,int resID){
		this.title = title;
		this.imageUrl = imageUrl;
		this.resID = resID;
	}
}
