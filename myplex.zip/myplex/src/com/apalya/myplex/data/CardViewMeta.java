package com.apalya.myplex.data;


public class CardViewMeta {
	public Object mObj;
	public CardViewHolder mUiHolder;
	public CardViewProperties mProperty;
}
