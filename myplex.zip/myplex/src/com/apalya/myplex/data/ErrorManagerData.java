package com.apalya.myplex.data;

public class ErrorManagerData {

	public String serviceName;
	public String contentName;
	public String url;
	public String apn;
	public String devicemodel;
	public String deviceosversion;
	public String deviceip;
	public String networkmode;
	public String networkstrength;
	public String batterystrength;
	public String userid;
	public String playposition;

	public ErrorManagerData(){
		
	}
	public ErrorManagerData(String serviceName, String contentName, String url,
			String apn, String devicemodel, String deviceosversion,
			String deviceip, String networkmode, String networkstrength,
			String batterystrength, String userid, String playposition) {

	}
}
