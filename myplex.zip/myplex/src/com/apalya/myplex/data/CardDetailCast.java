package com.apalya.myplex.data;

public class CardDetailCast extends CardDetailBaseData{

	
}
