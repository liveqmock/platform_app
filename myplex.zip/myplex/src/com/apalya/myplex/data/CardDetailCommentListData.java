package com.apalya.myplex.data;

import java.util.ArrayList;
import java.util.List;

public class CardDetailCommentListData extends CardDetailBaseData{
	public List<CardDetailCommentData> mList = new ArrayList<CardDetailCommentData>();
}
