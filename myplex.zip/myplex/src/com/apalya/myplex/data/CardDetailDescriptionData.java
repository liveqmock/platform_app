package com.apalya.myplex.data;

public class CardDetailDescriptionData extends CardDetailBaseData{
	public String mContentBriefDescription;
	public String mContentFullDescription;
	public float mRating;
	public String mTitle;
	public boolean mAlreadyExpanded = false;
}
