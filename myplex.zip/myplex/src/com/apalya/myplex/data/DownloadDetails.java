package com.apalya.myplex.data;

public class DownloadDetails {
	
	public String cardId;
	public String cardImage;
	public String downloadId;
	
	public DownloadDetails(){
		
	}

}
